#pragma once

#define STACK_SIZE (1024)
#define RTT_BUFFER_SIZE (512)
