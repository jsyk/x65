#pragma once

#include "common.h"
#include "stm32f0xx_hal_pcd.h"

#define assert_param(...)
