#pragma once

bool flash_mass_erase(void) __attribute__((section(".ramcode")));
