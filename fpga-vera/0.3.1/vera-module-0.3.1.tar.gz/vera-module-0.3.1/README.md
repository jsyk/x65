# VERA module - Video Embedded Retro Adapter
This repository contains the files related to the VERA module. This module is developed for the Commander X16 computer by The 8-Bit Guy.

**NOTE**: The Commander X16 logo is part of the Commander X16 project and should not be used when the module is used with other projects.
