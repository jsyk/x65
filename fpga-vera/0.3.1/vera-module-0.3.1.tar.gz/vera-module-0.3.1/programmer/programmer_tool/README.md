# install 
`sudo apt install pkg-config libusb-1.0-0-dev`
