#pragma once

#include "usbd_cdc.h"

extern const struct cdc_interface cdc_fops;
