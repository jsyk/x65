X65-SBC-rev.A1
================

X65 Single-Board Computer, schematic & PCB revision A1.

![3D render view of the X65-SBC rev.A1 (Kicad)](pictures/sbc-render-1.png)

![Schematic (PDF)](x65-sbc-revA1.pdf)


